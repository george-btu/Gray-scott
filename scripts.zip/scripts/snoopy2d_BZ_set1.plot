
set xlabel "x" 0,0
set ylabel "y" 0,0
set zlabel "BZ" 0,0

#set view 45, 315, 1, 1

set size square

set xrange [0:128] 
set yrange [0:128] 

set terminal postscript color
set output "BZ_set1.ps"

set pm3d map

splot 'data.dat.00000000' matrix with image
splot 'data.dat.00000001' matrix with image
splot 'data.dat.00000002' matrix with image
splot 'data.dat.00000003' matrix with image
splot 'data.dat.00000004' matrix with image
splot 'data.dat.00000005' matrix with image
splot 'data.dat.00000006' matrix with image
splot 'data.dat.00000007' matrix with image
splot 'data.dat.00000008' matrix with image
splot 'data.dat.00000009' matrix with image
splot 'data.dat.00000010' matrix with image
splot 'data.dat.00000011' matrix with image
splot 'data.dat.00000012' matrix with image
splot 'data.dat.00000013' matrix with image
splot 'data.dat.00000014' matrix with image 
splot 'data.dat.00000015' matrix with image
splot 'data.dat.00000016' matrix with image
splot 'data.dat.00000017' matrix with image
splot 'data.dat.00000018' matrix with image
splot 'data.dat.00000019' matrix with image 
splot 'data.dat.00000020' matrix with image
splot 'data.dat.00000021' matrix with image
splot 'data.dat.00000022' matrix with image
splot 'data.dat.00000023' matrix with image
splot 'data.dat.00000024' matrix with image
splot 'data.dat.00000025' matrix with image
splot 'data.dat.00000026' matrix with image
splot 'data.dat.00000027' matrix with image
splot 'data.dat.00000028' matrix with image
splot 'data.dat.00000029' matrix with image
splot 'data.dat.00000030' matrix with image
splot 'data.dat.00000031' matrix with image
splot 'data.dat.00000032' matrix with image
splot 'data.dat.00000033' matrix with image
splot 'data.dat.00000034' matrix with image 
splot 'data.dat.00000035' matrix with image
splot 'data.dat.00000036' matrix with image
splot 'data.dat.00000037' matrix with image
splot 'data.dat.00000038' matrix with image
splot 'data.dat.00000039' matrix with image 
splot 'data.dat.00000040' matrix with image
splot 'data.dat.00000041' matrix with image
splot 'data.dat.00000042' matrix with image
splot 'data.dat.00000043' matrix with image
splot 'data.dat.00000044' matrix with image 
splot 'data.dat.00000045' matrix with image
splot 'data.dat.00000046' matrix with image
splot 'data.dat.00000047' matrix with image
splot 'data.dat.00000048' matrix with image
splot 'data.dat.00000049' matrix with image 
splot 'data.dat.00000050' matrix with image